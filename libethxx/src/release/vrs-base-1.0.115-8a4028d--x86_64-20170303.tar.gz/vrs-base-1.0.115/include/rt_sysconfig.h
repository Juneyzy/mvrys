#ifndef __RT_SYSCONFIG_H__
#define __RT_SYSCONFIG_H__


struct sys_configure{

    int         serial_num;

    char    *decoder_config;

    char    *default_dir;

    char    *default_format;

    int     default_level;
    
};


#endif

