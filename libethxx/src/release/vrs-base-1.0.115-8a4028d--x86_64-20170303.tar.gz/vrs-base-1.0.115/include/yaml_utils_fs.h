#ifndef __UTILS_FS_H__
#define __UTILS_FS_H__

int PathIsRelative(const char *path) ;
int PathIsAbsolute(const char *path);

#endif
